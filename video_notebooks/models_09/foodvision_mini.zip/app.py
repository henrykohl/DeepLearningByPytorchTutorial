### 1. Imports and class names setup (步驟1) ###
import gradio as gr
import os 
import torch

from model import create_effnetb2_model
from timeit import default_timer as timer
from typing import Tuple, Dict

# Setup class names
class_names = ['pizza', 'steak', 'sushi']

### 2. Model and transforms perparation (步驟2) ###
"""Create EffNetB2 model: 獲得模型定義與變換"""
effnetb2, effnetb2_transforms = create_effnetb2_model(
    num_classes=3) # (len(class_names) would also work)

# Load save weights
"""加載權重到模型"""
effnetb2.load_state_dict(
  torch.load(
    f="09_pretrained_effnetb2_feature_extractor_pizza_steak_sushi_20_percent.pth",
    map_location=torch.device("cpu") # load the model to the CPU
  )
)

### 3. Predict function (步驟3) ### 
"""Create predict function: 建立預測函數 (from 7.2)"""
def predict(img) -> Tuple[Dict, float]:
  # Start a timer
  start_time = timer()

  # Transform the input image for use with EffNetB2
  """Transform the target image and add a batch dimension"""
  img = effnetb2_transforms(img).unsqueeze(0) # unsqueeze = add batch dimension on 0th index

  # Put model into eval mode, make prediction (Put model into evaluation mode and turn on inference mode)
  effnetb2.eval()
  with torch.inference_mode():
    # Pass transformed image through the model and turn the prediction logits into probaiblities
    """Pass the transformed image through the model and turn the prediction logits into prediction probabilities"""
    pred_probs = torch.softmax(effnetb2(img), dim=1)

  # Create a prediction label and prediction probability dictionary (for each prediction class (this is the required format for Gradio's output parameter))
  pred_labels_and_probs = {class_names[i]: float(pred_probs[0][i]) for i in range(len(class_names))}

  # Calculate pred time (prediction time)
  end_time = timer()
  pred_time = round(end_time - start_time, 4)

  # Return pred dict and pred time (the prediction dictionary and prediction time)
  return pred_labels_and_probs, pred_time

### 4. Gradio app (步驟4) ### 
"""(from 7.4)"""
# Create title, description and article (strings)
title = "FoodVision Mini 🍕🥩🍣"
description = "An [EfficientNetB2 feature extractor](https://pytorch.org/vision/stable/models/generated/torchvision.models.efficientnet_b2.html#torchvision.models.efficientnet_b2) computer vision model to classify images as pizza, steak or sushi."
article = "Created at [09. PyTorch Model Deployment](https://www.learnpytorch.io/09_pytorch_model_deployment/#74-building-a-gradio-interface)."

# Create example list (from "examples/" directory)
"""(based on 8.3)"""
example_list = [["examples/" + example] for example in os.listdir("examples")]

# Create the Gradio demo
demo = gr.Interface(fn=predict, # maps inputs to outputs #( mapping function from input to output)
            inputs=gr.Image(type="pil"), #( what are the inputs?)
            outputs=[gr.Label(num_top_classes=3, label="Predictions"), #( what are the outputs?)
                      gr.Number(label="Prediction time (s)")], #( our fn has two outputs, therefore we have two outputs)
            # (Create examples list from "examples/" directory)
            examples=example_list,
            title=title,
            description=description,
            article=article)

# Launch the demo!
demo.launch() 
